from django.apps import AppConfig

class HelloWorldConfig(AppConfig):
    name = 'helloWorld'
